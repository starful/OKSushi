import os
import re
import frontmatter
import json

# ==========================================
# ⚙️ 설정 (슬림 카테고리 매핑)
# ==========================================
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
CONTENT_DIRS = [
    os.path.join(BASE_DIR, 'app', 'content'),
    os.path.join(BASE_DIR, 'app', 'content', 'guides')
]

CAT_MAP = {
    "Luxury Omakase": "Omakase", "Edomae": "Omakase", "Traditional": "Omakase",
    "Michelin Star": "Michelin", "Premium": "Michelin",
    "Fun Kaiten": "Kaiten", "Market Fresh": "Market", "Fish Market": "Market",
    "Best Value": "Value", "Budget": "Value", "Affordable": "Value",
    "Solo Dining": "Solo", "Solo Friendly": "Solo", "Sushi & Sake": "Sake", "Pairing": "Sake",
    "명품 오마카세": "오마카세", "에도마에": "오마카세", "전통적인": "오마카세",
    "미슐랭 가이드": "미슐랭", "프리미엄": "미슐랭",
    "회전초밥 체험": "회전초밥", "수산시장 직송": "시장스시",
    "가성비 맛집": "가성비", "혼밥 성지": "혼밥", "혼밥가능": "혼밥", "스시와 사케": "사케/술"
}

def process_file(filepath):
    # 1. 생텍스트로 파일 읽기
    with open(filepath, 'r', encoding='utf-8') as f:
        content = f.read()

    # 2. YAML 영역과 본문 강제 분리 (정규표현식 사용)
    match = re.match(r'^---\s*\n(.*?)\n---\s*\n(.*)$', content, re.DOTALL)
    if not match:
        return False

    header_raw = match.group(1)
    body_content = match.group(2).strip()

    # 3. 헤더 데이터 수동 파싱 (딕셔너리 생성)
    metadata = {}
    for line in header_raw.split('\n'):
        if ':' in line:
            key, val = line.split(':', 1)
            key = key.strip()
            val = val.strip().strip('"').strip("'")
            
            if key == 'categories':
                # 카테고리 배열 추출 및 슬림화
                cats_raw = val.replace('[', '').replace(']', '').replace('"', '').replace("'", "")
                old_cats = [c.strip() for c in cats_raw.split(',') if c.strip()]
                new_cats = list(set([CAT_MAP.get(c, c) for c in old_cats]))
                metadata[key] = new_cats
            else:
                metadata[key] = val

    # 4. 본문 문법 교정
    body_content = re.sub(r'([^\n])\n##', r'\1\n\n##', body_content)
    body_content = re.sub(r'([^\n])\n###', r'\1\n\n###', body_content)
    body_content = re.sub(r'([^\n])\n\* ', r'\1\n\n* ', body_content)

    # 5. 💡 핵심: frontmatter 라이브러리를 사용해 "표준 규격"으로 저장
    # 이렇게 저장해야 build_data.py에서 에러가 안 납니다.
    post = frontmatter.Post(body_content, **metadata)
    with open(filepath, 'wb') as f:
        frontmatter.dump(post, f)
    
    return True

def run():
    print("🚀 [OKSushi] 마크다운 표준 규격 재건축 시작...")
    count = 0
    for d in CONTENT_DIRS:
        if not os.path.exists(d): continue
        for f in os.listdir(d):
            if f.endswith('.md'):
                if process_file(os.path.join(d, f)):
                    count += 1
                    if count % 20 == 0: print(f"  ✅ {count}개 재건축 완료...")

    print(f"\n✨ 총 {count}개의 파일을 표준 YAML 규격으로 완벽히 복구했습니다!")

if __name__ == "__main__":
    run()