/**
 * 🍣 OKSushi Main JavaScript
 * - 다국어 카테고리 매핑 및 실시간 숫자 업데이트 엔진
 * - 지도 마커 연동 및 동적 리스트 렌더링
 */

import { initGoogleMap, renderMarkers, filterItems } from './map-core.js';

// [전역 상태 설정]
let allItems = [];
let currentLang = 'en';
const DATA_KEY = 'sushis'; // config.py의 data_key와 일치

/**
 * 💡 핵심: 카테고리 매핑 사전
 * 마크다운 데이터(KO/EN)의 'categories' 필드값을 
 * HTML 버튼의 'data-theme' 및 'count-badge id'와 연결합니다.
 */
const CATEGORY_TO_THEME = {
    // 한국어 데이터 -> 영어 테마 ID
    "오마카세": "omakase",
    "미슐랭": "michelin",
    "회전초밥": "kaiten",
    "시장스시": "market",
    "가성비": "budget",
    "혼밥": "solo",
    "사케/술": "pairing",

    // 영어 데이터 -> 영어 테마 ID
    "Omakase": "omakase",
    "Michelin": "michelin",
    "Kaiten": "kaiten",
    "Market": "market",
    "Value": "budget",
    "Solo": "solo",
    "Sake": "pairing"
};

/**
 * 앱 초기화 (엔트리 포인트)
 */
async function init() {
    console.log("🚀 OKSushi premium engine starting...");

    // 1. URL 파라미터에서 현재 언어 감지 (?lang=ko 등)
    const urlParams = new URLSearchParams(window.location.search);
    currentLang = urlParams.get('lang') || 'en';

    // 2. 서버로부터 데이터 가져오기
    await fetchItems();

    // 3. 구글 맵 초기화
    const map = await initGoogleMap();
    
    // 4. 초기 렌더링
    renderMarkers(map, allItems);
    updateListView(allItems);
    updateFilterCounts(allItems); // 상단 숫자 업데이트 실행

    // 5. 필터 버튼 이벤트 바인딩
    setupFilters(map);
}

/**
 * API 호출: 현재 언어에 맞는 스시 리스트 로드
 */
async function fetchItems() {
    try {
        const response = await fetch(`/api/items?lang=${currentLang}`);
        const data = await response.json();
        
        allItems = data[DATA_KEY] || [];
        
        // 하단 상태바(개수, 업데이트 날짜) 반영
        const totalEl = document.getElementById('total-items');
        if (totalEl) totalEl.textContent = allItems.length;

        const dateEl = document.getElementById('last-updated-date');
        if (dateEl && data.last_updated) {
            dateEl.textContent = data.last_updated;
        }
    } catch (error) {
        console.error("❌ Data load failed:", error);
    }
}

/**
 * 💡 필터 버튼 옆의 숫자 배지를 실시간으로 계산해 표시
 */
function updateFilterCounts(items) {
    // 1. 모든 배지 숫자를 0으로 리셋
    document.querySelectorAll('.count-badge').forEach(badge => {
        badge.textContent = '0';
    });

    // 2. 'All(전체)' 버튼 숫자 설정
    const allBadge = document.getElementById('count-all');
    if (allBadge) allBadge.textContent = items.length;

    // 3. 각 아이템을 순회하며 카테고리별 합산 작업
    items.forEach(item => {
        if (item.categories && Array.isArray(item.categories)) {
            item.categories.forEach(cat => {
                // 매핑 사전에서 테마 ID를 찾음 (없으면 소문자 변환)
                const themeId = CATEGORY_TO_THEME[cat] || cat.toLowerCase().replace(/\s/g, '');
                
                // HTML의 id="count-테마명" 요소를 찾아 숫자 1 증가
                const badge = document.getElementById(`count-${themeId}`);
                if (badge) {
                    const currentVal = parseInt(badge.textContent) || 0;
                    badge.textContent = currentVal + 1;
                }
            });
        }
    });
}

/**
 * 필터 버튼 클릭 이벤트 설정
 */
function setupFilters(map) {
    const filterBtns = document.querySelectorAll('.theme-button');
    
    filterBtns.forEach(btn => {
        btn.addEventListener('click', () => {
            // 버튼 활성화 스타일 교체
            filterBtns.forEach(b => b.classList.remove('active'));
            btn.classList.add('active');

            const selectedTheme = btn.getAttribute('data-theme');

            // 💡 필터링 로직: 매핑 사전을 사용하여 데이터 명칭에 상관없이 매칭함
            const filtered = allItems.filter(item => {
                if (selectedTheme === 'all') return true;
                return item.categories.some(cat => {
                    const itemThemeId = CATEGORY_TO_THEME[cat] || cat.toLowerCase().replace(/\s/g, '');
                    return itemThemeId === selectedTheme;
                });
            });

            // 지도 마커 및 하단 카드 리스트 갱신
            renderMarkers(map, filtered);
            updateListView(filtered);
            
            // 모바일 배려: 리스트 영역으로 부드러운 스크롤
            if (window.innerWidth < 768 && selectedTheme !== 'all') {
                const listSection = document.getElementById('list-section');
                if (listSection) listSection.scrollIntoView({ behavior: 'smooth' });
            }
        });
    });
}

/**
 * 하단 스시 맛집 리스트 뷰 렌더링
 */
function updateListView(items) {
    const listContainer = document.getElementById('item-list');
    if (!listContainer) return;

    if (items.length === 0) {
        const noResultMsg = currentLang === 'ko' ? '해당 조건의 맛집이 없습니다.' : 'No spots found.';
        listContainer.innerHTML = `<div style="grid-column: 1/-1; text-align: center; padding: 100px 0; color: #bbb;">${noResultMsg}</div>`;
        return;
    }

    // 카드 HTML 생성 (상세 페이지 이동 시 현재 언어 유지되도록 ?lang= 추가)
    listContainer.innerHTML = items.map(item => `
        <a href="${item.link}?lang=${currentLang}" class="onsen-card">
            <img src="${item.thumbnail}" alt="${item.title}" class="card-thumb" loading="lazy">
            <div class="card-content">
                <h3 class="card-title">${item.title}</h3>
                <p class="card-summary">${item.summary}</p>
                <div class="card-meta">
                    <span>📍 ${item.address}</span>
                </div>
            </div>
        </a>
    `).join('');
}

// 스크립트 실행
document.addEventListener('DOMContentLoaded', init);